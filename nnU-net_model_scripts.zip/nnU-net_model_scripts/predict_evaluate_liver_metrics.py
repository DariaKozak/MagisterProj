import os
import subprocess
import nibabel as nib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import random
from tqdm import tqdm
from sklearn.metrics import precision_score, recall_score, f1_score

# Пути к папкам
project_root = os.path.expanduser("~/Desktop/nnU-Net")
input_dir = os.path.join(project_root, "selected_images")
output_dir = os.path.join(project_root, "predictions_selected_demo")
gt_dir = os.path.join(project_root, "nnUNet_raw/Dataset503_Liver/labelsTr")
labels = [1, 2]  # 1 = печень, 2 = опухоль

# Запуск предикта
print("🧠 Running prediction...")
subprocess.run([
    os.path.join(project_root, "nnunet-env/bin/nnUNetv2_predict"),
    "-d", "503",
    "-c", "2d",
    "-f", "0",
    "-i", input_dir,
    "-o", output_dir,
    "-chk", "checkpoint_best.pth",
    "--disable_tta",
    "--verbose",
    "-device", "cpu"
], check=True)

# Оценка
print("🧪 Evaluating predictions...")
metrics = []

for fname in tqdm(sorted(os.listdir(output_dir))):
    if not fname.endswith(".nii.gz"):
        continue
    case_id = fname.replace(".nii.gz", "")
    pred_path = os.path.join(output_dir, fname)
    gt_path = os.path.join(gt_dir, fname)

    if not os.path.exists(gt_path):
        print(f"⚠️ Missing ground truth for {fname}")
        continue

    pred = nib.load(pred_path).get_fdata().astype(np.uint8)
    gt = nib.load(gt_path).get_fdata().astype(np.uint8)

    row = {"case": case_id}
    for cls in labels:
        pred_bin = (pred == cls).astype(np.uint8).flatten()
        gt_bin = (gt == cls).astype(np.uint8).flatten()
        intersection = np.logical_and(pred_bin, gt_bin).sum()
        union = pred_bin.sum() + gt_bin.sum()
        dice = 2 * intersection / union if union > 0 else 0
        prec = precision_score(gt_bin, pred_bin, zero_division=0)
        recall = recall_score(gt_bin, pred_bin, zero_division=0)
        f1 = f1_score(gt_bin, pred_bin, zero_division=0)
        row.update({
            f"dice_class_{cls}": dice,
            f"precision_class_{cls}": prec,
            f"recall_class_{cls}": recall,
            f"f1_class_{cls}": f1
        })
    metrics.append(row)

df = pd.DataFrame(metrics)
csv_path = os.path.join(project_root, "predictions_selected_demo/liver_segmentation_metrics.csv")
df.to_csv(csv_path, index=False)

print("\n✅ Saved metrics to liver_segmentation_metrics.csv\n")
print("📊 Average metrics:")
print(df.drop(columns=["case"]).mean())

# Визуализация
print("\n🖼️ Generating example visualizations...")
os.makedirs(os.path.join(project_root, "predictions_selected_demo/prediction_examples"), exist_ok=True)

n = min(3, len(df))
if n > 0:
    cases = random.sample(df["case"].tolist(), k=n)

    for case_id in cases:
        pred = nib.load(os.path.join(output_dir, case_id + ".nii.gz")).get_fdata()
        gt = nib.load(os.path.join(gt_dir, case_id + ".nii.gz")).get_fdata()
        img = nib.load(os.path.join(input_dir, case_id + "_0000.nii.gz")).get_fdata()

        z = img.shape[0] // 2
        fig, axs = plt.subplots(1, 3, figsize=(15, 5))

        # Оригинальное изображение
        axs[0].imshow(img[z], cmap="gray")
        axs[0].set_title("Image")

        # Наложение ground truth
        axs[1].imshow(img[z], cmap="gray")
        axs[1].imshow(gt[z], cmap="Reds", alpha=0.4) 
        axs[1].set_title("Ground Truth (overlay)")

        # Наложение предсказания
        axs[2].imshow(img[z], cmap="gray")
        axs[2].imshow(pred[z], cmap="Blues", alpha=0.4)
        axs[2].set_title("Prediction (overlay)")
        for ax in axs:
            ax.axis("off")
        plt.tight_layout()
        plt.savefig(os.path.join(project_root, "predictions_selected_demo/prediction_examples", f"{case_id}.png"))
        plt.close()
