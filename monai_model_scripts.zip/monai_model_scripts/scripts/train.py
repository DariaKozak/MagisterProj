# Скрипт обучения (адаптирован под CPU MacBook)
import sys
import os
import matplotlib.pyplot as plt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import torch
from time import time
from datetime import datetime
from models.unet2d import get_model
from monai.networks.nets import UNet
from monai.losses import DiceLoss
from monai.metrics import DiceMetric
from monai.data import DataLoader, Dataset
from monai.transforms import (
    Compose, LoadImaged, EnsureChannelFirstd, ScaleIntensityd, Resized, ToTensord
)
from utils.logger import plot_training_progress


# Явно используем CPU
device = torch.device("cpu")
print(f"Using device: {device}")

data_dir = "data"
batch_size = 4
num_epochs = 30
lr = 1e-4

# Получаем списки файлов изображений и меток
image_paths = sorted([os.path.join(data_dir, "imagesTr", f) for f in os.listdir(os.path.join(data_dir, "imagesTr"))])
label_paths = sorted([os.path.join(data_dir, "labelsTr", f) for f in os.listdir(os.path.join(data_dir, "labelsTr"))])
train_files = [{"image": i, "label": l} for i, l in zip(image_paths, label_paths)]

# Трансформации для подготовки данных
train_transforms = Compose([
    LoadImaged(keys=["image", "label"]),
    EnsureChannelFirstd(keys=["image", "label"]),
    ScaleIntensityd(keys=["image"]),
    Resized(keys=["image", "label"], spatial_size=(256, 256)),
    ToTensord(keys=["image", "label"]),
])

train_ds = Dataset(data=train_files, transform=train_transforms)
train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)

# Определяем модель UNet
model = get_model().to(device)

# Лосс и оптимизатор
loss_function = DiceLoss(sigmoid=True)
optimizer = torch.optim.Adam(model.parameters(), lr=lr)

# Метрика Dice
dice_metric = DiceMetric(include_background=True, reduction="mean")

# Логи
os.makedirs("outputs/checkpoints", exist_ok=True)
logs = {
    "epoch": [],
    "train_loss": [],
    "val_loss": [],
    "dice": [],
    "epoch_time": [],
    "lr": []
}
best_loss = float("inf")

# Цикл обучения
for epoch in range(num_epochs):
    start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"Epoch {epoch+1}/{num_epochs}, Started at: {start_time}")
    start = time()

    model.train()
    epoch_loss = 0

    for batch_data in train_loader:
        inputs = batch_data["image"].to(device)
        labels = batch_data["label"].to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = loss_function(outputs, labels)
        loss.backward()
        optimizer.step()
        epoch_loss += loss.item()
    epoch_loss /= len(train_loader)
    print(f"Epoch {epoch+1}/{num_epochs}, Loss: {epoch_loss:.4f}")
    # Логирование
    logs["epoch"].append(epoch + 1)
    logs["train_loss"].append(epoch_loss)
    logs["val_loss"].append(epoch_loss * 0.9)  # заглушка
    logs["dice"].append(0.5 + 0.02 * epoch)    # заглушка
    logs["epoch_time"].append(time() - start)
    logs["lr"].append(optimizer.param_groups[0]["lr"])

    # Сохранение обычного чекпойнта
    ckpt_path = f"outputs/checkpoints/epoch_{epoch+1:03}.pth"
    torch.save(model.state_dict(), ckpt_path)
    print(f"✔️ Checkpoint saved: {ckpt_path}")

    # Сохранение лучшего чекпойнта
    if epoch_loss < best_loss:
        best_loss = epoch_loss
        best_ckpt_path = "outputs/checkpoints/checkpoint_best.pth"
        torch.save(model.state_dict(), best_ckpt_path)
        print(f"🏆 Best model saved: {best_ckpt_path}")
    
    plot_training_progress(logs)


# Сохраняем модель
os.makedirs("outputs", exist_ok=True)
torch.save(model.state_dict(), "outputs/unet2d_liver03.pth")
print("Модель сохранена.")
