import os
import nibabel as nib
import numpy as np
from PIL import Image

# Пути к данным
input_images_dir = "data/raw/imagesTr"
input_labels_dir = "data/raw/labelsTr"

# Папки для 2D-срезов
output_images_dir = "data/imagesTr"
output_labels_dir = "data/labelsTr"

os.makedirs(output_images_dir, exist_ok=True)
os.makedirs(output_labels_dir, exist_ok=True)

def save_slice(slice_data, path):
    """
    Сохраняет срез как PNG (с нормализацией до 0-255)
    """
    norm = (slice_data - slice_data.min()) / (slice_data.max() - slice_data.min() + 1e-8)
    img = Image.fromarray((norm * 255).astype(np.uint8))
    img.save(path)

def extract_slices(images_dir, labels_dir, output_img_dir, output_lbl_dir):
    """
    Извлекает 2D-срезы из 3D томов и сохраняет в PNG
    """
    image_files = sorted([f for f in os.listdir(images_dir) if f.endswith(".nii") or f.endswith(".nii.gz")])
    for img_file in image_files:
        base_id = img_file.replace("_0000.nii.gz", "").replace(".nii.gz", "").replace(".nii", "")
        lbl_file = base_id + ".nii.gz"
        if not os.path.exists(os.path.join(labels_dir, lbl_file)):
            lbl_file = base_id + ".nii"

        img_path = os.path.join(images_dir, img_file)
        lbl_path = os.path.join(labels_dir, lbl_file)

        img_nii = nib.load(img_path)
        lbl_nii = nib.load(lbl_path)

        img_data = img_nii.get_fdata()
        lbl_data = lbl_nii.get_fdata()

        for i in range(img_data.shape[2]):  # axial
            img_slice = img_data[:, :, i]
            lbl_slice = lbl_data[:, :, i]

            img_out_path = os.path.join(output_img_dir, f"{base_id}_slice_{i:03}.png")
            lbl_out_path = os.path.join(output_lbl_dir, f"{base_id}_slice_{i:03}.png")

            save_slice(img_slice, img_out_path)
            save_slice(lbl_slice, lbl_out_path)

        print(f"✓ Обработан {base_id}")

extract_slices(input_images_dir, input_labels_dir, output_images_dir, output_labels_dir)
print("✅ Все срезы успешно извлечены.")
