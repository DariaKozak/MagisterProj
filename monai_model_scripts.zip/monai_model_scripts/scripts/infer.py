import csv
import numpy as np
import matplotlib.pyplot as plt
import torch
import sys
import os
import matplotlib.pyplot as plt

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from models.unet2d import get_model
from monai.transforms import Compose, LoadImage, EnsureChannelFirst, Resize, ScaleIntensity, ToTensor
from monai.metrics import DiceMetric
from monai.networks.nets import UNet
from sklearn.metrics import precision_score, recall_score, f1_score

# Пути
image_dir = "data/selected_images/images"
label_dir = "data/selected_images/labels"
output_dir = "outputs/infer_selected"
os.makedirs(output_dir, exist_ok=True)

# Устройство
device = torch.device("cpu")

# Модель
model = get_model().to(device)

model.load_state_dict(torch.load("outputs/epoch_020.pth", map_location=device))
model.eval()

# Метрика
dice_metric = DiceMetric(include_background=True, reduction="mean")

# Трансформации
transforms = Compose([
    LoadImage(image_only=True),
    EnsureChannelFirst(),
    Resize((256, 256)),
    ScaleIntensity(),
    ToTensor()
])

# CSV-файл
csv_path = os.path.join(output_dir, "metrics.csv")
with open(csv_path, "w", newline="") as f_csv:
    writer = csv.writer(f_csv)
    writer.writerow(["filename", "dice"])

    for filename in sorted(os.listdir(image_dir)):
        if not filename.endswith(".png"):
            continue

        image_path = os.path.join(image_dir, filename)
        label_path = os.path.join(label_dir, filename)

        # Загрузка и предобработка
        image_tensor = transforms(image_path).unsqueeze(0).to(device)
        label_tensor = transforms(label_path).unsqueeze(0).to(device)

        # Инференс
        with torch.no_grad():
            pred = model(image_tensor)
            pred_mask = (pred.sigmoid() > 0.5).float()

        # Метрика
         # --- Dice ---
        dice_metric(y_pred=pred_mask, y=label_tensor)
        dice_score = dice_metric.aggregate().item()
        dice_metric.reset()

        # --- Обчислення інших метрик через sklearn ---
        pred_bin = pred_mask[0, 0].cpu().numpy().astype(np.uint8)
        label_bin = label_tensor[0, 0].cpu().numpy().astype(np.uint8)

        pred_flat = pred_bin.flatten()
        label_flat = label_bin.flatten()

        precision = precision_score(label_flat, pred_flat, zero_division=0)
        recall = recall_score(label_flat, pred_flat, zero_division=0)
        f1 = f1_score(label_flat, pred_flat, zero_division=0)

         # --- Запис у CSV ---
        writer.writerow([
            filename,
            f"{dice_score:.4f}",
            f"{precision:.4f}",
            f"{recall:.4f}",
            f"{f1:.4f}"
        ])

        print(f"{filename}: Dice={dice_score:.4f}, Precision={precision:.4f}, Recall={recall:.4f}, F1={f1:.4f}")

        # Визуализация
        img_np = image_tensor[0, 0].cpu().numpy()
        lbl_np = label_tensor[0, 0].cpu().numpy()
        pred_np = pred_mask[0, 0].cpu().numpy()

        fig, axs = plt.subplots(1, 3, figsize=(12, 4))
        axs[0].imshow(img_np, cmap="gray")
        axs[0].set_title("Image")
        axs[1].imshow(lbl_np, cmap="viridis")
        axs[1].set_title("Ground Truth")
        axs[2].imshow(pred_np, cmap="plasma")
        axs[2].set_title(f"Prediction")

        for ax in axs:
            ax.axis("off")

        plt.tight_layout()
        vis_path = os.path.join(output_dir, f"{filename.replace('.png', '')}_vis.png")
        plt.savefig(vis_path)
        plt.close()

print(f"\n✅ Метрики сохранены в: {csv_path}")
