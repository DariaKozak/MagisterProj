# Скрипт валидации (адаптирован под CPU MacBook)
import os
import torch
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from monai.metrics import DiceMetric
from monai.data import DataLoader, Dataset
from models.unet2d import get_model
from utils.metrics import get_dice_metric
from monai.transforms import (
    Compose, LoadImaged, EnsureChannelFirstd, ScaleIntensityd, Resized, ToTensord
)



# Используем CPU
device = torch.device("cpu")
print(f"Using device: {device}")

# Список файлов для валидации (предполагается, что имена файлов связаны)
val_files = [{"image": f"data/imagesTr/{f}", "label": f"data/labelsTr/{f.replace('image', 'label')}"} 
             for f in sorted(os.listdir("data/imagesTr"))[:1000]]


val_transforms = Compose([
    LoadImaged(keys=["image", "label"]),
    EnsureChannelFirstd(keys=["image", "label"]),
    ScaleIntensityd(keys=["image"]),
    Resized(keys=["image", "label"], spatial_size=(256, 256)),
    ToTensord(keys=["image", "label"]),
])


val_ds = Dataset(data=val_files, transform=val_transforms)
val_loader = DataLoader(val_ds, batch_size=1)

# Загружаем модель
model = get_model().to(device)
model.load_state_dict(torch.load("outputs/checkpoint_best.pth", map_location=device))
model.eval()

dice_metric = DiceMetric(include_background=True, reduction="mean")

for val_data in val_loader:
    inputs = val_data["image"].to(device)
    labels = val_data["label"].to(device)

    with torch.no_grad():
        outputs = model(inputs)
        dice_metric(y_pred=outputs, y=labels)

dice_score = dice_metric.aggregate().item()
dice_metric.reset()

print(f"Dice на валидации: {dice_score:.4f}")
